<?php
$host     = "localhost";    // Nama host
$username = "arsc3651_dinaspangan";         // Username database
$password = "solupa99";   // Password database
$database = "arsc3651_dinaspangan";   // Nama database